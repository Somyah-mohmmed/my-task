const connectBtn = document.getElementById('connect-btn');
const actionsBar = document.getElementById('actions-bar');
const controlBar = document.getElementById('control-bar');
const statusText = document.getElementById('status');

let isConnected = false;

function toggleConnection() {
    if (isConnected) {
        actionsBar.classList.remove('open')
        actionsBar.classList.add('closed')
        controlBar.style.display = 'none';
        statusText.innerText = 'Disconnected';
        statusText.style.color = 'gray';
        connectBtn.innerText = 'Connect';
        
    } else {
        actionsBar.classList.remove('closed')
        actionsBar.classList.add('open')
        controlBar.style.display = 'block';
        statusText.innerText = 'Connected';
        statusText.style.color = '#008006';
        connectBtn.innerText = 'Disconnect';
    }

    isConnected ^= true;
}

connectBtn.addEventListener('click', (e) => {
    toggleConnection();
});